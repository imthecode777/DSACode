#include <stdio.h>
#include <stdlib.h>
#define MAX 5

int deque[MAX];
int front = -1, rear = -1;

void insertFront(int item);
void insertRear(int item);
void deleteFront();
void deleteRear();
void display();

int main()
{
    int choice, item;

    while (1)
    {
        printf("\n--- DEQUEUE MENU ---\n");
        printf("1. Insert Front\n");
        printf("2. Insert Rear\n");
        printf("3. Delete Front\n");
        printf("4. Delete Rear\n");
        printf("5. Display\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            printf("Enter element to insert at front: ");
            scanf("%d", &item);
            insertFront(item);
            break;

        case 2:
            printf("Enter element to insert at rear: ");
            scanf("%d", &item);
            insertRear(item);
            break;

        case 3:
            deleteFront();
            break;

        case 4:
            deleteRear();
            break;

        case 5:
            display();
            break;

        case 6:
            printf("Exiting...\n");
            exit(0);

        default:
            printf("Invalid choice! Try again.\n");
        }
    }
    return 0;
}

void insertFront(int item)
{
    if ((front == 0 && rear == MAX - 1) || (front == rear + 1))
    {
        printf("Dequeue Overflow! Cannot insert.\n");
        return;
    }

    if (front == -1)
    { 
        front = rear = 0;
    }
    else if (front == 0)
    {
        front = MAX - 1;
    }
    else
    {
        front--;
    }
    deque[front] = item;
    printf("%d inserted at front.\n", item);
}

void insertRear(int item)
{
    if ((front == 0 && rear == MAX - 1) || (front == rear + 1))
    {
        printf("Dequeue Overflow! Cannot insert.\n");
        return;
    }

    if (front == -1)
    { 
        front = rear = 0;
    }
    else if (rear == MAX - 1)
    {
        rear = 0;
    }
    else
    {
        rear++;
    }
    deque[rear] = item;
    printf("%d inserted at rear.\n", item);
}


void deleteFront()
{
    if (front == -1)
    {
        printf("Dequeue Underflow! Nothing to delete.\n");
        return;
    }

    printf("%d deleted from front.\n", deque[front]);

    if (front == rear)
    { 
        front = rear = -1;
    }
    else if (front == MAX - 1)
    {
        front = 0;
    }
    else
    {
        front++;
    }
}


void deleteRear()
{
    if (front == -1)
    {
        printf("Dequeue Underflow! Nothing to delete.\n");
        return;
    }

    printf("%d deleted from rear.\n", deque[rear]);

    if (front == rear)
    { 
        front = rear = -1;
    }
    else if (rear == 0)
    {
        rear = MAX - 1;
    }
    else
    {
        rear--;
    }
}

void display()
{
    int i;
    if (front == -1)
    {
        printf("Dequeue is empty.\n");
        return;
    }

    printf("Dequeue elements: ");
    if (front <= rear)
    {
        for (i = front; i <= rear; i++)
            printf("%d ", deque[i]);
    }
    else
    {
        for (i = front; i < MAX; i++)
            printf("%d ", deque[i]);
        for (i = 0; i <= rear; i++)
            printf("%d ", deque[i]);
    }
    printf("\n");
}