#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX 100

typedef struct Node
{
    char data;
    struct Node *left, *right;
} Node;

typedef struct
{
    Node *arr[MAX];
    int top;
} Stack;

void initStack(Stack *s);
int isEmpty(Stack *s);
void push(Stack *s, Node *node);
Node *pop(Stack *s);
int precedence(char op);
int isOperator(char c);
Node *createNode(char data);
Node *constructTree(char *postfix);
void inorder(Node *root);
void preorder(Node *root);
void postorder(Node *root);
void infixToPostfix(char *infix, char *postfix);


void initStack(Stack *s)
{
    s->top = -1;
}
int isEmpty(Stack *s)
{
    return s->top == -1;
}
void push(Stack *s, Node *node)
{
    s->arr[++(s->top)] = node;
}
Node *pop(Stack *s)
{
    return s->arr[(s->top)--];
}

int precedence(char op)
{
    switch (op)
    {
    case '+':
    case '-':
        return 1;
    case '*':
    case '/':
        return 2;
    case '^':
        return 3;
    }
    return 0;
}
int isOperator(char c)
{
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

Node *createNode(char data)
{
    Node *newNode = (Node *)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

void infixToPostfix(char *infix, char *postfix)
{
    char stack[MAX];
    int top = -1, k = 0;
    for (int i = 0; infix[i] != '\0'; i++)
    {
        char c = infix[i];

        if (isalnum(c))
        {
            postfix[k++] = c;
        }
        else if (c == '(')
        {
            stack[++top] = c;
        }
        else if (c == ')')
        {
            while (top != -1 && stack[top] != '(')
                postfix[k++] = stack[top--];
            top--; // pop '('
        }
        else if (isOperator(c))
        {
            while (top != -1 && precedence(stack[top]) >= precedence(c))
                postfix[k++] = stack[top--];
            stack[++top] = c;
        }
    }
    while (top != -1)
        postfix[k++] = stack[top--];
    postfix[k] = '\0';
}

Node *constructTree(char *postfix)
{
    Stack s;
    initStack(&s);

    for (int i = 0; postfix[i] != '\0'; i++)
    {
        char c = postfix[i];
        Node *node = createNode(c);

        if (isOperator(c))
        {
            node->right = pop(&s);
            node->left = pop(&s);
        }
        push(&s, node);
    }
    return pop(&s);
}

void preorder(Node *root)
{ // Prefix
    if (root != NULL)
    {
        printf("%c", root->data);
        preorder(root->left);
        preorder(root->right);
    }
}
void postorder(Node *root)
{ 
    if (root != NULL)
    {
        postorder(root->left);
        postorder(root->right);
        printf("%c", root->data);
    }
}

int main()
{
    char infix[MAX], postfix[MAX];
    printf("Enter an arithmetic expression (infix): ");
    scanf("%s", infix);

    infixToPostfix(infix, postfix);
    printf("Postfix Expression: %s\n", postfix);

    Node *root = constructTree(postfix);

    printf("Prefix Expression: ");
    preorder(root);
    printf("\n");

    printf("Postfix Expression (from tree): ");
    postorder(root);
    printf("\n");

    return 0;
}