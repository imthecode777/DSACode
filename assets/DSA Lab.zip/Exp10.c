#include <stdio.h>
#include <stdlib.h>

#define MAX 100


long bubbleSteps = 0, insertionSteps = 0, radixSteps = 0;


void bubbleSort(int arr[], int n)
{
    int i, j, temp;
    for (i = 0; i < n - 1; i++)
    {
        for (j = 0; j < n - i - 1; j++)
        {
            bubbleSteps++; 
            if (arr[j] > arr[j + 1])
            {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                bubbleSteps++;
            }
        }
    }
}


void insertionSort(int arr[], int n)
{
    int i, key, j;
    for (i = 1; i < n; i++)
    {
        key = arr[i];
        j = i - 1;
        insertionSteps++;
        while (j >= 0 && arr[j] > key)
        {
            arr[j + 1] = arr[j];
            j = j - 1;
            insertionSteps++; 
        }
        arr[j + 1] = key;
    }
}


int getMax(int arr[], int n)
{
    int mx = arr[0];
    for (int i = 1; i < n; i++)
    {
        if (arr[i] > mx)
            mx = arr[i];
    }
    return mx;
}


void countSort(int arr[], int n, int exp)
{
    int output[n];
    int count[10] = {0};

    for (int i = 0; i < n; i++)
    {
        count[(arr[i] / exp) % 10]++;
        radixSteps++;
    }

    for (int i = 1; i < 10; i++)
    {
        count[i] += count[i - 1];
        radixSteps++;
    }

    for (int i = n - 1; i >= 0; i--)
    {
        output[count[(arr[i] / exp) % 10] - 1] = arr[i];
        count[(arr[i] / exp) % 10]--;
        radixSteps++;
    }

    for (int i = 0; i < n; i++)
    {
        arr[i] = output[i];
        radixSteps++;
    }
}


void radixSort(int arr[], int n)
{
    int m = getMax(arr, n);
    for (int exp = 1; m / exp > 0; exp *= 10)
        countSort(arr, n, exp);
}


void printArray(int arr[], int n)
{
    for (int i = 0; i < n; i++)
        printf("%d%s", arr[i], (i < n - 1) ? ", " : ".");
}


int main()
{
    int arr[MAX], n;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++)
        printf("Enter The Element[%d]: ", i + 1), scanf("%d", &arr[i]);

    int arr1[MAX], arr2[MAX], arr3[MAX];
    for (int i = 0; i < n; i++)
    {
        arr1[i] = arr[i];
        arr2[i] = arr[i];
        arr3[i] = arr[i];
    }

    bubbleSort(arr1, n);
    insertionSort(arr2, n);
    radixSort(arr3, n);

    printf("\nSorted Array (Bubble Sort): ");
    printArray(arr1, n);
    printf("Steps (Bubble Sort): %ld\n", bubbleSteps);

    printf("\nSorted Array (Insertion Sort): ");
    printArray(arr2, n);
    printf("Steps (Insertion Sort): %ld\n", insertionSteps);

    printf("\nSorted Array (Radix Sort): ");
    printArray(arr3, n);
    printf("Steps (Radix Sort): %ld\n", radixSteps);

    return 0;
}