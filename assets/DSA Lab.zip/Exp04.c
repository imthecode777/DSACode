#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 100

char stack[MAX];
int top = -1;

int intStack[MAX];
int intTop = -1;

void push(char);
char pop();
char peek();
int precedence(char);
int isOperator(char);
void infixToPostfix(char infix[], char postfix[]);
void infixToPrefix(char infix[], char prefix[]);
int evaluatePostfix(char exp[]);
int evaluatePrefix(char exp[]);
int applyOperation(int a, int b, char op);
void reverseString(char str[]);

void intPush(int val);
int intPop();

int main()
{
    int choice;
    char infix[MAX], postfix[MAX], prefix[MAX];

    while (1)
    {
        printf("---- MENU ----\n");
        printf("1. Convert to Postfix\n");
        printf("2. Convert to Prefix\n");
        printf("3. Evaluate Postfix Expression\n");
        printf("4. Evaluate Prefix Expression\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // consume newline

        switch (choice)
        {
        case 1:
            printf("Enter infix expression: ");
            fgets(infix, MAX, stdin);
            infix[strcspn(infix, "\n")] = 0;
            infixToPostfix(infix, postfix);
            printf("Postfix Expression: %s\n", postfix);
            break;

        case 2:
            printf("Enter infix expression: ");
            fgets(infix, MAX, stdin);
            infix[strcspn(infix, "\n")] = 0;
            infixToPrefix(infix, prefix);
            printf("Prefix Expression: %s\n", prefix);
            break;

        case 3:
            printf("Enter postfix expression: ");
            fgets(postfix, MAX, stdin);
            postfix[strcspn(postfix, "\n")] = 0;
            printf("Result: %d\n", evaluatePostfix(postfix));
            break;

        case 4:
            printf("Enter prefix expression: ");
            fgets(prefix, MAX, stdin);
            prefix[strcspn(prefix, "\n")] = 0;
            printf("Result: %d\n", evaluatePrefix(prefix));
            break;

        case 5:
            printf("Exiting...\n");
            exit(0);

        default:
            printf("Invalid choice! Try again.\n");
        }
    }

    return 0;
}

void push(char c)
{
    stack[++top] = c;
}
char pop()
{
    return stack[top--];
}
char peek()
{
    return stack[top];
}

void intPush(int val)
{
    intStack[++intTop] = val;
}
int intPop()
{
    return intStack[intTop--];
}

int precedence(char c)
{
    switch (c)
    {
    case '^':
        return 3;
    case '*':
    case '/':
        return 2;
    case '+':
    case '-':
        return 1;
    default:
        return 0;
    }
}

int isOperator(char c)
{
    return (c == '+' || c == '-' || c == '*' || c == '/' || c == '^');
}

void reverseString(char str[])
{
    int len = strlen(str);
    for (int i = 0; i < len / 2; i++)
    {
        char temp = str[i];
        str[i] = str[len - i - 1];
        str[len - i - 1] = temp;
    }
}

void infixToPostfix(char infix[], char postfix[])
{
    top = -1;
    int i, k = 0;
    char ch;

    for (i = 0; infix[i] != '\0'; i++)
    {
        ch = infix[i];

        if (isalnum(ch))
            postfix[k++] = ch;
        else if (ch == '(')
            push(ch);
        else if (ch == ')')
        {
            while (top != -1 && peek() != '(')
                postfix[k++] = pop();
            pop();
        }
        else if (isOperator(ch))
        {
            while (top != -1 && precedence(peek()) >= precedence(ch))
                postfix[k++] = pop();
            push(ch);
        }
    }

    while (top != -1)
        postfix[k++] = pop();

    postfix[k] = '\0';
}

void infixToPrefix(char infix[], char prefix[])
{
    char rev[MAX], post[MAX];
    strcpy(rev, infix);
    reverseString(rev);

    for (int i = 0; rev[i] != '\0'; i++)
    {
        if (rev[i] == '(')
            rev[i] = ')';
        else if (rev[i] == ')')
            rev[i] = '(';
    }

    infixToPostfix(rev, post);
    reverseString(post);
    strcpy(prefix, post);
}

int evaluatePostfix(char exp[])
{
    intTop = -1;
    for (int i = 0; exp[i] != '\0'; i++)
    {
        if (isdigit(exp[i]))
        {
            intPush(exp[i] - '0');
        }
        else if (isOperator(exp[i]))
        {
            int val2 = intPop();
            int val1 = intPop();
            intPush(applyOperation(val1, val2, exp[i]));
        }
    }
    return intPop();
}

int evaluatePrefix(char exp[])
{
    intTop = -1;
    int len = strlen(exp);
    for (int i = len - 1; i >= 0; i--)
    {
        if (isdigit(exp[i]))
        {
            intPush(exp[i] - '0');
        }
        else if (isOperator(exp[i]))
        {
            int val1 = intPop();
            int val2 = intPop();
            intPush(applyOperation(val1, val2, exp[i]));
        }
    }
    return intPop();
}

int applyOperation(int a, int b, char op)
{
    switch (op)
    {
    case '+':
        return a + b;
    case '-':
        return a - b;
    case '*':
        return a * b;
    case '/':
        return a / b;
    case '^':
    {
        int res = 1;
        for (int i = 0; i < b; i++)
            res *= a;
        return res;
    }
    default:
        return 0;
    }
}