#include <stdio.h>

#define MAX 100 // Maximum number of non-zero elements

// Structure to represent a sparse matrix
struct SparseMatrix
{
    int row, col, value; // Row, Coloumn, Non-zero value
};

// Function to read a sparse matrix
int readSparseMatrix(struct SparseMatrix mat[])
{
    int rows, cols, n;
    printf("Enter number of rows, columns, and non-zero elements: ");
    scanf("%d %d %d", &rows, &cols, &n);

    mat[0].row = rows;
    mat[0].col = cols;
    mat[0].value = n;

    printf("Enter row, column, and value for each non-zero element:\n");
    for (int i = 1; i <= n; i++)
    {
        printf("Element %d: ", i);
        scanf("%d %d %d", &mat[i].row, &mat[i].col, &mat[i].value);
    }

    return n;
}

// Function to display a sparse matrix in triplet form
void displaySparseMatrix(struct SparseMatrix mat[])
{
    int n = mat[0].value;
    printf("\nRow\tCol\tValue\n");
    for (int i = 0; i <= n; i++)
    {
        printf("%d\t%d\t%d\n", mat[i].row, mat[i].col, mat[i].value);
    }
}

// Function to find the transpose of a sparse matrix
void transposeSparseMatrix(struct SparseMatrix mat[], struct SparseMatrix trans[])
{
    int n = mat[0].value;
    trans[0].row = mat[0].col;
    trans[0].col = mat[0].row;
    trans[0].value = n;

    int k = 1;

    // For each column, find elements and place them in transposed order
    for (int col = 0; col < mat[0].col; col++)
    {
        for (int i = 1; i <= n; i++)
        {
            if (mat[i].col == col)
            {
                trans[k].row = mat[i].col;
                trans[k].col = mat[i].row;
                trans[k].value = mat[i].value;
                k++;
            }
        }
    }
}

// Main function
int main()
{
    int n;
    struct SparseMatrix mat[MAX], trans[MAX];

    n = readSparseMatrix(mat);

    printf("\nOriginal Sparse Matrix:");
    displaySparseMatrix(mat);

    transposeSparseMatrix(mat, trans);

    printf("\nTransposed Sparse Matrix:");
    displaySparseMatrix(trans);

    return 0;
}
