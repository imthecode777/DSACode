#include <stdio.h>

#define MAX 100

typedef struct
{
    int row, col, val;
} term;

void readSparse(term a[])
{
    printf("Enter number of rows, columns and non-zero elements: ");
    scanf("%d %d %d", &a[0].row, &a[0].col, &a[0].val);
    int t = a[0].val;

    printf("Enter row, column, and value for each non-zero element:\n");
    for (int i = 1; i <= t; i++)
    {
        printf("Element %d: ", i);
        scanf("%d %d %d", &a[i].row, &a[i].col, &a[i].val);
    }
}

void printSparse(term a[])
{
    int t = a[0].val;
    printf("\nRow\tCol\tValue\n");
    for (int i = 1; i <= t; i++)
    {
        printf("%d\t%d\t%d\n", a[i].row, a[i].col, a[i].val);
    }
}

void addSparse(term a[], term b[], term c[])
{
    int i = 1, j = 1, k = 1;

    if (a[0].row != b[0].row || a[0].col != b[0].col)
    {
        printf("\nAddition not possible! Matrices dimensions differ.\n");
        c[0].val = 0;
        return;
    }

    c[0].row = a[0].row;
    c[0].col = a[0].col;

    while (i <= a[0].val && j <= b[0].val)
    {
        if (a[i].row == b[j].row && a[i].col == b[j].col)
        {
            c[k].row = a[i].row;
            c[k].col = a[i].col;
            c[k].val = a[i].val + b[j].val;
            i++;
            j++;
            k++;
        }
        else if (a[i].row < b[j].row || (a[i].row == b[j].row && a[i].col < b[j].col))
        {
            c[k++] = a[i++];
        }
        else
        {
            c[k++] = b[j++];
        }
    }

    while (i <= a[0].val)
        c[k++] = a[i++];
    while (j <= b[0].val)
        c[k++] = b[j++];

    c[0].val = k - 1;
}

int main()
{
    term a[MAX], b[MAX], c[MAX];

    printf("Enter details for first sparse matrix:\n");
    readSparse(a);

    printf("\nEnter details for second sparse matrix:\n");
    readSparse(b);

    addSparse(a, b, c);

    printf("\nResultant Sparse Matrix (Sum):\n");
    printSparse(c);

    return 0;
}