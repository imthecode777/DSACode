#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure for a node in BST
struct Node
{
    char word[50];     // key
    char meaning[100]; // value
    struct Node *left, *right;
};

// Create a new node
struct Node *createNode(char *word, char *meaning)
{
    struct Node *newNode = (struct Node *)malloc(sizeof(struct Node));
    strcpy(newNode->word, word);
    strcpy(newNode->meaning, meaning);
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Insert into BST
struct Node *insert(struct Node *root, char *word, char *meaning)
{
    if (root == NULL)
        return createNode(word, meaning);

    if (strcmp(word, root->word) < 0)
        root->left = insert(root->left, word, meaning);
    else if (strcmp(word, root->word) > 0)
        root->right = insert(root->right, word, meaning);
    else
        printf("Word '%s' already exists in dictionary!\n", word);

    return root;
}

// Search for a word
struct Node *search(struct Node *root, char *word)
{
    if (root == NULL || strcmp(word, root->word) == 0)
        return root;

    if (strcmp(word, root->word) < 0)
        return search(root->left, word);
    else
        return search(root->right, word);
}

// In-order traversal (sorted dictionary)
void inorder(struct Node *root)
{
    if (root != NULL)
    {
        inorder(root->left);
        printf("%s : %s\n", root->word, root->meaning);
        inorder(root->right);
    }
}

int main()
{
    struct Node *root = NULL;
    int choice;
    char word[50], meaning[100];
    struct Node *result;

    while (1)
    {
        printf("\n--- Dictionary Menu ---\n");
        printf("1. Insert word\n");
        printf("2. Search word\n");
        printf("3. Display dictionary (sorted)\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        getchar(); // clear newline

        switch (choice)
        {
        case 1:
            printf("Enter word: ");
            fgets(word, sizeof(word), stdin);
            word[strcspn(word, "\n")] = 0; // remove newline

            printf("Enter meaning: ");
            fgets(meaning, sizeof(meaning), stdin);
            meaning[strcspn(meaning, "\n")] = 0;

            root = insert(root, word, meaning);
            break;

        case 2:
            printf("Enter word to search: ");
            fgets(word, sizeof(word), stdin);
            word[strcspn(word, "\n")] = 0;

            result = search(root, word);
            if (result != NULL)
                printf("Meaning of '%s': %s\n", result->word, result->meaning);
            else
                printf("Word not found in dictionary.\n");
            break;

        case 3:
            printf("\n--- Dictionary Contents (Alphabetical) ---\n");
            inorder(root);
            break;

        case 4:
            printf("Exiting...\n");
            exit(0);

        default:
            printf("Invalid choice!\n");
        }
    }

    return 0;
}